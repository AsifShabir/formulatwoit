<?php
namespace Mirakl\Core\Exception;

class ApiException extends \Exception
{}
<?php
namespace Mirakl\Core\Exception;

class ClientDisabledException extends ApiException
{}
<?php
namespace Mirakl\Core\Exception;

class RequestValidationException extends ApiException
{}
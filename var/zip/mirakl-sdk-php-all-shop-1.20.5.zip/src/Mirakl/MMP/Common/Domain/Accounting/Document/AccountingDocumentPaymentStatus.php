<?php
namespace Mirakl\MMP\Common\Domain\Accounting\Document;

class AccountingDocumentPaymentStatus
{
    const AWAITING_PAYMENT = 'AWAITING_PAYMENT';
    const PAID             = 'PAID';
    const PENDING          = 'PENDING';
}
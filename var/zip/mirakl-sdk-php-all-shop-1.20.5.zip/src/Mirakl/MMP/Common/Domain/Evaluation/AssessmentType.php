<?php
namespace Mirakl\MMP\Common\Domain\Evaluation;

class AssessmentType
{
    const GRADE   = 'GRADE';
    const BOOLEAN = 'BOOLEAN';
}
<?php
namespace Mirakl\MMP\Common\Domain\Order\Async\Export;

use Mirakl\Core\Domain\MiraklObject;

/**
 * @method string getTrackingId()
 * @method $this  setTrackingId(string $trackingId)
 */
class ExportOrdersAsyncSubmitResponse extends MiraklObject
{}
<?php
namespace Mirakl\MMP\Common\Domain\Order\Tax;

class OrderTaxMode
{
    const TAX_EXCLUDED = 'TAX_EXCLUDED';
    const TAX_INCLUDED = 'TAX_INCLUDED';
}
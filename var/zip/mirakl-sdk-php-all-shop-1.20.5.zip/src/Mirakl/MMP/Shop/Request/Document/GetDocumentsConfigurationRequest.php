<?php
namespace Mirakl\MMP\Shop\Request\Document;

use Mirakl\MMP\Common\Request\Document\AbstractGetDocumentsConfigurationRequest;

/**
 * (DO01) Get the list of all document types
 */
class GetDocumentsConfigurationRequest extends AbstractGetDocumentsConfigurationRequest
{}